# Токен бота
BOT_TOKEN = "7427355085:AAHkc_FoasqupEsMCIzYebuBKJQBYkIY6sA"

# Конфигурация базы данных
DATABASE_TYPE = "sqlite"
DATABASE_NAME = "university_bot.db"
ADMIN_ID = 6031684537  # ID администратора
MEDIA_PATH = "media"   # Путь к папке для медиафайлов